# mega-tic-tac-toe
A Tic-Tac-Toe project for MP-ITKMITL subject.
